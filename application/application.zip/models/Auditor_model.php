<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auditor_model extends CI_Model {

  public function __construct()
  {
    parent::__construct();
    $this->load->database();
  }

  public function get_auditor()
  {
      $this->db->select('*');
      $this->db->from('auditor');
      $query = $this->db->get();
      return $query->result_array();
  }
  
  public function update_auditor($id)
  {
      $this->db->select('*');
      $this->db->from('auditor');
      $this->db->join('user', 'user.id_user = auditor.user_id');
      $this->db->where('user_id', $id);
      $query = $this->db->get();
      return $query->row_array();
  }

  public function act_update_auditor($data, $id)
  {
      $this->db->where('id_auditor',$id);
      return $this->db->update('auditor',$data);
    
  }

  public function update_user($data,$id)
    {
        $this->db->where('id_user',$id);
        return $this->db->update('user',$data);

    }
}
