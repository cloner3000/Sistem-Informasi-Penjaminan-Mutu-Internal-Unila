<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html>
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Sistem Penjaminan Mutu Internal Unila">
    <meta name="keywords" content="Audit, Audit Internal, SPMI, Unila, ilmu Komputer">
    <meta name="author" content="Adji Pangestu">

    <link rel="icon" type="image/png" href="<?php echo base_url("assets/img/unila.png");?>">
    <title>E-LP3M - Universitas Lampung</title>

    <link href="<?php echo base_url("assets/css/bootstrap.min.css");?>" rel="stylesheet">
    <link href="<?php echo base_url("assets/font-awesome/css/font-awesome.css");?>" rel="stylesheet">

    <link href="<?php echo base_url("assets/css/animate.css");?>" rel="stylesheet">
    <link href="<?php echo base_url("assets/css/style.css");?>" rel="stylesheet">

</head>

<body class="gray-bg">

    <div class="loginColumns animated fadeInDown">
        <div class="row">

            <div class="col-md-6">
				<img src="<?php echo base_url("assets/img/unila.png");?>" alt="unila" class="img-lg">
                <h2 class="font-bold">Selamat Datang di E-LP3M</h2>

                <h3>
                    <b>Sistem Penjaminan Mutu Internal.</b>
				</h3>

                <p>
					Lembaga Pengembangan Pembelajaran dan Penjaminan Mutu (LP3M). 
                </p>

                <p>
                    Universitas Lampung.
                </p>

            </div>
            <div class="col-md-6">
                <div class="ibox-content">
                    <form class="m-t" raction="<?php echo base_url('auth/login');?>" role="login" method="post">
                        <div id="myalert">
			                <?php echo $this->session->flashdata('alert', true)?>
		                </div>
                        <div class="form-group">
                            <input type="text" name="username" class="form-control" placeholder="Username" required="">
                        </div>
                        <div class="form-group">
                            <input type="password" name="password" class="form-control" placeholder="Password" required="">
                        </div>
                        <button name="submit" type="submit" value="login" class="btn btn-primary block full-width m-b">Login</button>

                        <a href="#">
                            <small>Forgot password?</small>
                        </a>

                       </form>
                </div>
            </div>
        </div>
        <hr/>
        <div class="row">
            <div class="col-md-6">
                Copyright © 2019 LP3M Unila. 
            </div>
            <div class="col-md-6 text-right">
               <i class="fa fa-linkedin-square"></i> Develop by <a href="">A. Pangestu</a>
            </div>
        </div>
    </div>

        <!-- Mainly scripts -->
    <script src="<?php echo base_url("assets/js/jquery-3.1.1.min.js");?>"></script>
    <script src="<?php echo base_url("assets/js/popper.min.js");?>"></script>
    <script src="<?php echo base_url("assets/js/bootstrap.js");?>"></script>
    <script src="<?php echo base_url("assets/js/plugins/metisMenu/jquery.metisMenu.js");?>"></script>
    <script src="<?php echo base_url("assets/js/plugins/slimscroll/jquery.slimscroll.min.js");?>"></script>

    <!-- Custom and plugin javascript -->
    <script src="<?php echo base_url("assets/js/inspinia.js");?>"></script>
    <script src="<?php echo base_url("assets/js/plugins/pace/pace.min.js");?>"></script>

<script>
  $('#myalert').delay('slow').slideDown('slow').delay(4100).slideUp(600);
</script>

</body>
</html>
