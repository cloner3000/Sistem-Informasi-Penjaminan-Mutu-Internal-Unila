<div class="footer">
    <div class="float-right">
         Powered by <strong>AM</strong>
    </div>
    <div>
        <strong>Copyright</strong> &copy; 2019 LP3M Universitas Lampung
    </div>
</div>