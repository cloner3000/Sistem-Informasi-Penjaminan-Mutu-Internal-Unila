<nav class="navbar-default navbar-static-side" role="navigation">
        <div class="sidebar-collapse">
            <ul class="nav metismenu" id="side-menu">
                <li class="nav-header">
                    <div class="dropdown profile-element">
                        <img alt="unila" class="img-circle" height="40" width="40" src="<?php echo base_url("assets/img/unila.png");?>"/>
                        <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                            <span class="block m-t-xs font-bold"><?php echo $this->session->userdata('username'); ?></span>
                            <span class="text-muted text-xs block">Option <b class="caret"></b></span>
                        </a>
                        <ul class="dropdown-menu animated fadeInRight m-t-xs">
                            <?php if($this->session->userdata('role_id') == "2"){?>
                                <li><a class="dropdown-item" href="<?php echo base_url().'tpm/tpm_prodi/detail_user/'.$this->session->userdata('id_user')?>">Profile</a></li>
                                <li class="dropdown-divider"></li>
                            <?php }?>
                            <?php if($this->session->userdata('role_id') == "5"){?>
                                <li><a class="dropdown-item" href="<?php echo base_url().'tpm/tpm_lab/detail_user/'.$this->session->userdata('id_user')?>">Profile</a></li>
                                <li class="dropdown-divider"></li>
                            <?php }?>
                            <?php if($this->session->userdata('role_id') == "6"){?>
                                <li><a class="dropdown-item" href="<?php echo base_url().'tpm/tpm_upt/detail_user/'.$this->session->userdata('id_user')?>">Profile</a></li>
                                <li class="dropdown-divider"></li>
                            <?php }?>
                            <?php if($this->session->userdata('role_id') == "7"){?>
                                <li><a class="dropdown-item" href="<?php echo base_url().'tpm/tpm_lembaga/detail_user/'.$this->session->userdata('id_user')?>">Profile</a></li>
                                <li class="dropdown-divider"></li>
                            <?php }?>
                            <?php if($this->session->userdata('role_id') == "8"){?>
                                <li><a class="dropdown-item" href="<?php echo base_url().'tpm/tpm_badan/detail_user/'.$this->session->userdata('id_user')?>">Profile</a></li>
                                <li class="dropdown-divider"></li>
                            <?php }?>
                            <?php if($this->session->userdata('role_id') == "3"){?>
                                <li><a class="dropdown-item" href="<?php echo base_url().'auditor/detail_user/'.$this->session->userdata('id_user')?>">Profile</a></li>
                                <li class="dropdown-divider"></li>
                            <?php }?>
                            <li><a class="dropdown-item" href="<?php echo base_url('auth/logout');?>">Logout</a></li>
                        </ul>
                    </div>
                    <div class="logo-element">
                        E-LP3M
                    </div>
                </li>
                <li href="<?php echo base_url(); ?>home" <?php if($this->uri->segment(1) =="home"){echo 'class="active"';}?>>
                    <a href="<?php echo base_url(); ?>home"><i class="fa fa-home"></i> <span class="nav-label">Beranda</span></a>
                </li>
                <!-- <li href="<?php echo base_url(); ?>chatt" <?php if($this->uri->segment(1) =="chatt"){echo 'class="active"';}?>>
                    <a href="<?php echo base_url(); ?>chatt"><i class="fa fa-comments"></i> <span class="nav-label">Chatt</span></a>
                </li> -->
                <!-- <li href="<?php echo base_url(); ?>audit" <?php if($this->uri->segment(1) =="audit"){echo 'class="active"';}?>>
                    <a href="<?php echo base_url(); ?>audit"><i class="fa fa-home"></i> <span class="nav-label">Coba</span></a>
                </li> -->
                <?php if($this->session->userdata('role_id') == '1') {?>
                <li href="#" 
                    <?php if($this->uri->segment(2) =="user")
                    {
                        echo 'class="active"';
                    }?>>
                    <a href="#"><i class="fa fa-users"></i> <span class="nav-label">Manajemen User</span><span class="fa arrow"></a>
                    <ul class="nav nav-second-level">
                        <li <?php if($this->uri->segment(2) =="semua_user")
                        {
                            echo 'class="active"';
                        }?>>
                            <a href="<?php echo base_url(); ?>su/user/semua_user"><span class="nav-label">Semua User</span></a>
                        </li>
                        <li <?php if($this->uri->segment(3) =="user_auditor")
                        {
                            echo 'class="active"';
                        }?>>
                            <a href="<?php echo base_url(); ?>su/user/user_auditor"><span class="nav-label">User Auditor</span></a>
                        </li>
                        <li <?php if($this->uri->segment(3) =="user_prodi")
                        {
                            echo 'class="active"';
                        }?>>
                            <a href="<?php echo base_url(); ?>su/user/user_prodi"><span class="nav-label">User Prodi</span></a>
                        </li>
                        <li <?php if($this->uri->segment(3) =="user_lab")
                        {
                            echo 'class="active"';
                        }?>>
                            <a href="<?php echo base_url(); ?>su/user/user_lab"><span class="nav-label">User Laboratorium</span></a>
                        </li>
                        <li <?php if($this->uri->segment(3) =="user_unit")
                        {
                            echo 'class="active"';
                        }?>>
                            <a href="<?php echo base_url(); ?>su/user/user_unit"><span class="nav-label">User Unit Pelaksana</span></a>
                        </li>
                        <li <?php if($this->uri->segment(3) =="user_lembaga")
                        {
                            echo 'class="active"';
                        }?>>
                            <a href="<?php echo base_url(); ?>su/user/user_lembaga"><span class="nav-label">User Pusat Lembaga</span></a>
                        </li>
                        <li <?php if($this->uri->segment(3) =="user_badan")
                        {
                            echo 'class="active"';
                        }?>>
                            <a href="<?php echo base_url(); ?>su/user/user_badan"><span class="nav-label">User Badan Pengelola</span></a>
                        </li>
                    </ul>
                </li>
                <li href="<?php echo base_url(); ?>dosen" <?php if($this->uri->segment(2) =="dosen"){echo 'class="active"';}?>>
                    <a href="<?php echo base_url(); ?>su/dosen"><i class="fa fa-user"></i> <span class="nav-label">Data Dosen Remun</span></a>
                </li>
                <li <?php if($this->uri->segment(2) =="borang")
                        {
                            echo 'class="active"';
                        }
                        else{
                            if($this->uri->segment(3) == "set_aspek")
                            {
                                echo 'class="active"';
                            }
                        }
                    ?>>
                <a href="#"><i class="fa fa-files-o"></i> <span class="nav-label">Manajemen Borang</span><span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level">
                        <li <?php if($this->uri->segment(3) =="instrumen")
                        {
                            echo 'class="active"';
                        } ?>>
                            <a href="<?php echo base_url(); ?>su/borang/instrumen"><span class="nav-label">Set Borang</span></a>
                        </li>
                        <li <?php if($this->uri->segment(3) =="set_aspek")
                        {
                            echo 'class="active"';
                        } ?>>
                            <a href="<?php echo base_url(); ?>su/borang/set_aspek"><span class="nav-label">Set Aspek Penilaian</span></a>
                        </li>
                        <li <?php if($this->uri->segment(3) =="set_pertanyaan")
                        {
                            echo 'class="active"';
                        } ?>>
                            <a href="<?php echo base_url(); ?>su/borang/set_pertanyaan"><span class="nav-label">Set Pertanyaan</span></a>
                        </li>
                        <li <?php if($this->uri->segment(3) =="instrumen_praktikum")
                        {
                            echo 'class="active"';
                        } ?>>
                            <a href="<?php echo base_url(); ?>su/borang/borang_pratikum"><span class="nav-label">Borang Praktikum</span><span class="fa arrow"></span></a>
                            <ul class="nav nav-third-level">
                                <li <?php if($this->uri->segment(3) =="instrumen_praktikum")
                                    {
                                        echo 'class="active"';
                                    } ?>>
                                    <a href="<?php echo base_url(); ?>su/borang/instrumen_praktikum">Set Borang</a>
                                </li>
                                <li <?php if($this->uri->segment(3) =="aspek_praktikum")
                                    {
                                        echo 'class="active"';
                                    } ?>>
                                    <a href="<?php echo base_url(); ?>su/borang/aspek_praktikum">Set Aspek Penilaian</a>
                                </li>
                                <li <?php if($this->uri->segment(3) =="set_pertanyaan_praktikum")
                                    {
                                        echo 'class="active"';
                                    } ?>>
                                    <a href="<?php echo base_url(); ?>su/borang/set_pertanyaan_praktikum">Set Pertanyaan</a>
                                </li>

                            </ul>
                        </li>
                    </ul>
                </li>
                
                <li href="<?php echo base_url(); ?>laporan" <?php if($this->uri->segment(1) =="laporan"){echo 'class="active"';}?>>
                    <a href="<?php echo base_url(); ?>laporan"><i class="fa fa-line-chart"></i> <span class="nav-label">Kelola Laporan</span></a>
                </li>

                <li href="<?php echo base_url(); ?>rekap" <?php if($this->uri->segment(1) =="rekapitulasi"){echo 'class="active"';}?>>
                    <a href="<?php echo base_url(); ?>rekapitulasi"><i class="fa fa-book"></i> <span class="nav-label">Kelola Rekapitulasi</span></a>
                </li>

                <li href="<?php echo base_url(); ?>fakultas" <?php if($this->uri->segment(2) =="fakultas"){echo 'class="active"';}?>>
                    <a href="<?php echo base_url(); ?>su/fakultas"><i class="fa fa-university"></i> <span class="nav-label">Kelola Fakultas</span></a>
                </li>
                
                <li href="<?php echo base_url(); ?>prodi" <?php if($this->uri->segment(2) =="prodi"){echo 'class="active"';}?>>
                    <a href="<?php echo base_url(); ?>su/prodi"><i class="fa fa-university"></i> <span class="nav-label">Kelola Program Studi</span></a>
                </li>

                <li href="<?php echo base_url(); ?>lab" <?php if($this->uri->segment(2) =="lab"){echo 'class="active"';}?>>
                    <a href="<?php echo base_url(); ?>su/lab"><i class="fa fa-university"></i> <span class="nav-label">Kelola Laboratorium</span></a>
                </li>

                <li href="<?php echo base_url(); ?>upt" <?php if($this->uri->segment(2) =="upt"){echo 'class="active"';}?>>
                    <a href="<?php echo base_url(); ?>su/upt"><i class="fa fa-university"></i> <span class="nav-label">Kelola Unit Pelaksana</span></a>
                </li>

                <li href="<?php echo base_url(); ?>lembaga" <?php if($this->uri->segment(2) =="lembaga"){echo 'class="active"';}?>>
                    <a href="<?php echo base_url(); ?>su/lembaga"><i class="fa fa-university"></i> <span class="nav-label">Kelola Pusat Lembaga</span></a>
                </li>

                <li href="<?php echo base_url(); ?>badan" <?php if($this->uri->segment(2) =="badan"){echo 'class="active"';}?>>
                    <a href="<?php echo base_url(); ?>su/badan"><i class="fa fa-university"></i> <span class="nav-label">Kelola Badan Pengelola</span></a>
                </li>

                <?php } ?>

                <!-- operator dan super -->

                <?php if($this->session->userdata('role_id') == '4') {?>
                <li href="<?php echo base_url(); ?>jadwal" <?php if($this->uri->segment(1) =="jadwal"){echo 'class="active"';}?>>
                    <a href="<?php echo base_url(); ?>jadwal"><i class="fa fa-calendar"></i> <span class="nav-label">Kelola Jadwal Audit</span></a>
                </li>
                <li href="<?php echo base_url(); ?>tahun_akademik" <?php if($this->uri->segment(1) =="tahun_akademik"){echo 'class="active"';}?>>
                    <a href="<?php echo base_url(); ?>tahun_akademik"><i class="fa fa-calendar"></i> <span class="nav-label">Set Tahun Akdemik</span></a>
                </li>
                <li href="<?php echo base_url(); ?>tahun_akademik" <?php if($this->uri->segment(1) =="tahun_akademik"){echo 'class="active"';}?>>
                    <a href="<?php echo base_url(); ?>tahun_akademik"><i class="fa fa-calendar"></i> <span class="nav-label">Set Auditor</span></a>
                </li>
                <?php } ?>

                <?php if($this->session->userdata('role_id') == '2') {?>
                    <li href="<?php echo base_url(); ?>tpm/tpm_prodi/set_kurikulum" <?php if($this->uri->segment(3) =="set_kurikulum"){echo 'class="active"';}?>>
                        <a href="<?php echo base_url(); ?>tpm/tpm_prodi/set_kurikulum"><i class="fa fa-calendar"></i> <span class="nav-label">Set Kurikulum</span></a>
                    </li>
                    <li>
                        <a href="<?php echo base_url(); ?>audit_ps/audit_matkul"><i class="fa fa-briefcase"></i> <span class="nav-label">  Audit Matakuliah</span></a>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-briefcase"></i> <span class="nav-label">  Daftar Audit</span></a>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-briefcase"></i> <span class="nav-label">  Hasil Audit </span></a>
                    </li>
                <?php } ?>

                <li href="<?php echo base_url(); ?>faq" <?php if($this->uri->segment(2) =="faq"){echo 'class="active"';}?>>
                    <a href="https://www.linkedin.com/in/adjipangestu/"><i class="fa fa-apple"></i> <span class="nav-label">About</span></a>
                </li>

                <li href="<?php echo base_url(); ?>help" <?php if($this->uri->segment(2) =="help"){echo 'class="active"';}?>>
                    <a href="https://www.linkedin.com/in/adjipangestu/"><i class="fa fa-question-circle"></i> <span class="nav-label">Help</span></a>
                </li>
            </ul>
            
        </div>
</nav>