<!DOCTYPE html>
<html lang="en-US">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- =========================
    Meta Information
    ============================== -->
    <meta name="description" content="Sistem Penjaminan Mutu Internal Unila">
    <meta name="keywords" content="Audit, Audit Internal, SPMI, Unila, ilmu Komputer">
    <meta name="author" content="Adji Pangestu">

    <link rel="icon" type="image/png" href="<?php echo base_url("assets/img/unila.png");?>">
    <title>E-LP3M - Universitas Lampung</title>

    <link href="<?php echo base_url("assets/css/bootstrap.min.css");?>" rel="stylesheet">
    <link href="<?php echo base_url("assets/font-awesome/css/font-awesome.css");?>" rel="stylesheet">
    <link href="<?php echo base_url("assets/css/animate.css");?>" rel="stylesheet">
    <link href="<?php echo base_url("assets/css/style.css");?>" rel="stylesheet">
    
    <link href="<?php echo base_url("assets/css/plugins/ladda/ladda-themeless.min.css");?>" rel="stylesheet">


    <link href="<?php echo base_url("assets/css/plugins/datapicker/datepicker3.css");?>" rel="stylesheet">
    <link href="<?php echo base_url("assets/css/plugins/dataTables/datatables.min.css");?>" rel="stylesheet">
    <link href="<?php echo base_url("assets/css/plugins/daterangepicker/daterangepicker-bs3.css");?>" rel="stylesheet">
    <link href="<?php echo base_url("assets/css/plugins/select2/select2.min.css");?>" rel="stylesheet">
    <link href="<?php echo base_url("assets/css/plugins/chosen/bootstrap-chosen.css");?>" rel="stylesheet">
    <link href="<?php echo base_url("assets/css/plugins/footable/footable.core.css");?>" rel="stylesheet">  
    <link href="<?php echo base_url("assets/css/plugins/steps/jquery.steps.css");?>" rel="stylesheet">
    <link href="<?php echo base_url("assets/css/plugins/iCheck/custom.css");?>" rel="stylesheet">
    <link href="<?php echo base_url("assets/plugins/sweetalert2/dist/sweetalert2.min.css");?>" rel="stylesheet"/>

</head>

<body>

<div id="wrapper">
<!-- main menu -->
<?php $this->view('layouts/main_menu');?>
<!-- end main menu -->

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
             <!-- header -->
             <?php $this->view('layouts/header');?>
            <!-- end header -->
            </div>

            <!-- content -->
            <?php echo $contents?>
            <!-- end content -->


            <!-- footer -->
            <?php $this->view('layouts/footer');?>
            <!-- end footer -->

        </div>
</div>


    <!-- Mainly scripts -->
    <script src="<?php echo base_url('assets/js/jquery-3.1.1.min.js');?>"></script>
    <script src="<?php echo base_url('assets/js/popper.min.js');?>"></script>
    <script src="<?php echo base_url('assets/js/bootstrap.js');?>"></script>

    <script src="<?php echo base_url('assets/js/plugins/metisMenu/jquery.metisMenu.js');?>"></script>
    <script src="<?php echo base_url('assets/js/plugins/slimscroll/jquery.slimscroll.min.js');?>"></script>

    <!-- Custom and plugin javascript -->
    <script src="<?php echo base_url('assets/js/inspinia.js');?>"></script>
    <script src="<?php echo base_url('assets/js/plugins/pace/pace.min.js');?>"></script>

    <script src="<?php echo base_url("assets/js/plugins/dataTables/datatables.min.js");?>"></script>
    <script src="<?php echo base_url("assets/js/plugins/dataTables/dataTables.bootstrap4.min.js");?>"></script>
    <script src="<?php echo base_url("assets/js/my-script.js");?>"></script>
    <script src="<?php echo base_url("assets/js/plugins/datapicker/bootstrap-datepicker.js");?>"></script>
    <script src="<?php echo base_url("assets/js/plugins/select2/select2.full.min.js");?>"></script>
    <script src="<?php echo base_url("assets/js/plugins/footable/footable.all.min.js");?>"></script> 
    <script src="<?php echo base_url("assets/js/plugins/steps/jquery.steps.min.js");?>"></script>
    <script src="<?php echo base_url("assets/js/plugins/validate/jquery.validate.min.js");?>"></script>
    <script src="<?php echo base_url("assets/plugins/sweetalert2/dist/sweetalert2.all.js");?>"></script>
    <script src="<?php echo base_url("assets/plugins/sweetalert2/dist/sweetalert2.min.js");?>"></script>
    <script src="<?php echo base_url("assets/js/plugins/chosen/chosen.jquery.js");?>"></script>

        <!-- Ladda -->
    <script src="<?php echo base_url("assets/js/plugins/ladda/spin.min.js");?>"></script>
    <script src="<?php echo base_url("assets/js/plugins/ladda/ladda.min.js");?>"></script>
    <script src="<?php echo base_url("assets/js/plugins/ladda/ladda.jquery.min.js");?>"></script>


    <script>
         var base_url = '<?php echo base_url()?>';
    </script>

</body>

</html>
