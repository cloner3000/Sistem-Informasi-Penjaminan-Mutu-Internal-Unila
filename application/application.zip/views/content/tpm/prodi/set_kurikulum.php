<div class="row wrapper border-bottom white-bg page-heading">
    <div class="col-lg-8">
        <h2>Kurikulum</h2>
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="#">Beranda</a>
                </li>
                <li class="breadcrumb-item active">
                    <strong>Kurikulum</strong>
                </li>      
            </ol>
    </div>
    <div class="col-lg-4">
        <div class="title-action">
            <button data-toggle="modal" href="#tambah-kurikulum" class="btn btn-primary float-right" type="submit"><i class="fa fa-pencil-square-o"></i> Tambah Data</button>
        </div>   
    </div>
</div>

<div class="wrapper wrapper-content animated fadeInUp">
    <div class="row">
        <div class="col-lg-12">
            <div class="ibox ">
                <div class="ibox-title">
                    <h5>Daftar Kurikulum</h5>
                </div>
                <div class="ibox-content">
                    <div class="table-responsive">
                        <table id="kurikulum" class="table table-striped table-bordered table-hover kurikulum" >
                            <thead>
                                <tr>   
                                    <th>Kurikulum</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                    
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th>Kurikulum</th>
                                    <th>Aksi</th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="daftar_matakuliah">
    <div class="row">
        <div class="col-lg-12">
            <div class="ibox"> 
                
            </div>        
        </div>
    </div>
    </div>
</div>



<div id="tambah-kurikulum" class="modal inmodal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
    <div class="modal-content animated bounceInRight">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
            <!-- <i class="fa fa-user modal-icon"></i> -->
            <h4 class="modal-title">Tambah Data</h4>
        </div>
        <div class="modal-body">
        <form  id="tambah_kurikulum"class="form-horizontal">
            <div class="form-group">
                <label class="font-normal"><b>kurikulum</b></label>
                <?php if ($this->session->userdata('role_id') == '2') {?>
                    <?php foreach ($tpm_prodi as $tpmp):?>
                        <?php if ($this->session->userdata('id_user') == $tpmp['user_id'] ) {?>
                            <input id="prodi_id" name="prodi_id" type="hidden" value="<?php echo $tpmp['prodi_id']?>">
                        <?php }?>
                    <?php endforeach;?>
                <?php }?>
                <input id="kurikulum_tahun" name="kurikulum" type="number" placeholder="Kurikulum" class="form-control">
            </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-danger" data-dismiss="modal">Batal</button>
            <button type="submit" id="submit" class="btn btn-primary">Simpan</button>
        </div>
        </form>
    </div>
    </div>
</div>

<div id="tambah-matkul" class="modal inmodal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg">
    <div class="modal-content animated bounceInRight">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
            <!-- <i class="fa fa-user modal-icon"></i> -->
            <h4 class="modal-title">Tambah Data</h4>
        </div>
        <div class="modal-body">
            <div id="form_tambah_matkul">
            
            </div>
        </div>
    </div>
    </div>
</div>







