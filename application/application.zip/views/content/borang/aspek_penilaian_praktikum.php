<div class="row wrapper border-bottom white-bg page-heading">
    <div class="col-lg-8">
        <h2>Aspek Penilaian Praktikum</h2>
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="#">Beranda</a>
                </li>
                <li class="breadcrumb-item">
                    Manajemen Borang
                </li> 
                <li class="breadcrumb-item">
                    Borang Praktikum
                </li> 
                <li class="breadcrumb-item active">
                    <strong>Aspek Penilaian Praktikum</strong>
                </li>      
            </ol>
    </div>
    <div class="col-lg-4">
        <div class="ibox-content center">
            <div class="title-action">
                <button data-toggle="modal" href="#set-aspek-praktikum" class="btn btn-primary float-right" type="submit"><i class="fa fa-pencil-square-o"></i> Tambah Data</button>
            </div>  
        </div>   
    </div>
</div>

<div class="wrapper wrapper-content animated fadeInRight">
    <div class="row">
        <div class="col-lg-12">
            <div class="ibox ">
                <div class="ibox-title">
                    <h5>Aspek Penilaian</h5>
                </div>
                <div class="ibox-content">
                    <div class="table-responsive">
                        <table id="aspek_praktikum" class="table table-striped table-bordered table-hover aspek_praktikum" >
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Aspek Penilaian</th>
                                    <th>Jenis Borang Kuliah</th>
                                    <th>Max Bobot</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                    
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th>No</th>
                                    <th>Aspek Penilaian Kuliah</th>
                                    <th>Jenis Borang</th>
                                    <th>Max Bobot</th>
                                    <th>Aksi</th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="set-aspek-praktikum" class="modal inmodal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
    <div class="modal-content animated bounceInRight">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
            <!-- <i class="fa fa-user modal-icon"></i> -->
            <h4 class="modal-title">Tambah Data</h4>
        </div>
        <div class="modal-body">
        <form  id="tambah_aspek_praktikum"class="form-horizontal">
            <div class="form-group">
                <label><b>Jenis Borang</b></label> 
                <select class="jenis form-control" name="jenis_borang_praktikum_id" id="jenis_borang_praktikum_id">
                      <option value="">- Jenis Borang Kuliah -</option>
                      <?php foreach($jenis_borang as $row):?>
                      <option  value="<?php echo $row['jenis_borang_id']?>"><?php echo $row['jenis_borang'] ?> <?php echo $row['tahun']?></option>
                  <?php endforeach;?>
                </select>
            </div>
            <div class="form-group">
                <label><b>Aspek Penilaian</b></label> 
                <input  id="aspek_penilaian" name="aspek_penilaian" type="text" placeholder="Aspek Penilaian" class="form-control required">
            </div>
            <div class="form-group">
                <label><b>Max Bobot</b></label> 
                <input  id="max_bobot" name="max_bobot" type="number" placeholder="bobot" class="form-control required">
            </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-danger" data-dismiss="modal">Batal</button>
            <button type="submit" id="submit" class="btn btn-primary">Simpan</button>
        </div>
        </form>
    </div>
    </div>
</div>

<div id="ubah_aspek_praktikum" class="modal inmodal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
    <div class="modal-content animated bounceInRight">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
            <!-- <i class="fa fa-user modal-icon"></i> -->
            <h4 class="modal-title">Edit Data</h4>
        </div>
        <div class="modal-body">
            <div id="form_edit_aspek_praktikum">

            </div>
        </div>
        
    </div>
    </div>
</div>

<script>

</script>
