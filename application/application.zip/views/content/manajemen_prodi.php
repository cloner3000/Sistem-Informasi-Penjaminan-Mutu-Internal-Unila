<div class="row wrapper border-bottom white-bg page-heading">
    <div class="col-lg-8">
        <h2>Program Studi</h2>
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="#">Beranda</a>
                </li>
                <li class="breadcrumb-item active">
                    <strong>Kelola Program Studi</strong>
                </li>      
            </ol>
    </div>
    <div class="col-lg-4">
        <div class="title-action">
            <button data-toggle="modal" href="#tambah-prodi" class="btn btn-primary float-right" type="submit"><i class="fa fa-pencil-square-o"></i> Tambah Data</button>
        </div>   
    </div>
    
</div>

<div class="wrapper wrapper-content animated fadeInUp">
    <div class="row">
        <div class="col-lg-12">
            <div class="ibox ">
                <div class="ibox-title">
                    <h5>Daftar Program Studi</h5>
                </div>
                <div class="ibox-content">
                    <div class="table-responsive">
                        <table id="manajemen_prodi" class="table table-striped table-bordered table-hover manajemen_user" >
                            <thead>
                                <tr>   
                                    <th>Prodi</th>
                                    <th>Fakultas</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                    
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th>Prodi</th>
                                    <th>Fakultas</th>
                                    <th>Aksi</th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div id="tambah-prodi" class="modal inmodal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
    <div class="modal-content animated bounceInRight">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
            <!-- <i class="fa fa-user modal-icon"></i> -->
            <h4 class="modal-title">Tambah Data</h4>
        </div>
        <div class="modal-body">
        <form  id="tambah_prodi"class="form-horizontal">
            <div class="form-group">
                <label class="font-normal"><b>Fakultas</b></label>
                <select  id="fakultas_id" name="fakultas_id" data-placeholder="Choose a Country..." class="form-control"  tabindex="2">
                    <option value="0">-PILIH-</option>
                    <?php foreach ($fakultas->result() as $key): ?>
                    <option value="<?php echo $key->id_fakultas;?>"><?php echo $key->nama_fakultas; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label class="font-normal"><b>Strata</b></label>
                <select id="strata_id" data-placeholder="Choose a Country..." class="form-control"  tabindex="2">
                <?php foreach ($strata->result() as $key): ?>
                    <option value="<?php echo $key->id_strata;?>"><?php echo $key->strata; ?></option>
                <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label class="font-normal"><b>Program Studi</b></label>
                <input id="program_studi" name="program_studi" type="text" placeholder="Program Studi" class="form-control">
            </div>
            <div class="form-group">
                <label class="font-normal"><b>Ketua Prodi</b></label>
                <input id="nama_kaprodi" name="nama_kaprodi"  type="text" placeholder="Ketua kaprodi" class="form-control">
            </div>
            <div class="form-group">
                <label class="font-normal"><b>NIP Ketua Prodi</b></label>
                <input id="nip_kaprodi" name="nip_kaprodi"  type="text" placeholder="NIP kaprodi" class="form-control">
            </div>
            <div class="form-group">
                <label class="font-normal"><b>Masa Jabatan</b><small class="text-info"></small></label>
                    <div class="input-daterange input-group" id="datepicker">
                        <input id="mulai_jabatan"  name="mulai_jabatan" type="text" class="form-control-sm form-control"data-provide="datepicker" data-date-format="yyyy-mm-dd" value="2019-09-20"/>
                        <span class="input-group-addon">to</span>
                        <input id="selesai_jabatan" name="selesai_jabatan" type="text" class="form-control-sm form-control" data-provide="datepicker" data-date-format="yyyy-mm-dd" value="2019-09-20" />
                    </div>
            </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-danger" data-dismiss="modal">Batal</button>
            <button type="submit" id="submit" class="btn btn-primary">Simpan</button>
        </div>
        </form>
    </div>
    </div>
</div>
<div id="detail_prodi" class="modal inmodal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
    <div class="modal-content animated bounceInRight">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
            <!-- <i class="fa fa-user modal-icon"></i> -->
            <h4 class="modal-title">Detail Prodi</h4>
        </div>
        <div class="modal-body">
            <div id="tampil_prodi">
        
            </div>
        </div>
    </div>
    </div>
</div>
<div id="ubah_prodi" class="modal inmodal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content animated bounceInRight">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                    <!-- <i class="fa fa-user modal-icon"></i> -->
                <h4 class="modal-title">Edit Data</h4>
            </div>
        <div class="modal-body">
        <div id="form_edit_prodi">
        
        </div>
    </div>
</div>
</div>
</div>

<div id="ganti_kaprodi" class="modal inmodal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content animated bounceInRight">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                    <!-- <i class="fa fa-user modal-icon"></i> -->
                <h4 class="modal-title">Ganti Kepala Program Studi</h4>
            </div>
            <div class="modal-body">
                <div id="form_ganti_kaprodi">
        
                </div>
            </div>
        </div>
    </div>
</div>


