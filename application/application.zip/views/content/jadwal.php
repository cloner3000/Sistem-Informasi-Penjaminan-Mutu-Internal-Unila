<div class="row wrapper border-bottom white-bg page-heading">
    <div class="col-lg-8">
        <h2>Jadwal</h2>
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="#">Beranda</a>
                </li>
                <li class="breadcrumb-item active">
                    <strong>Kelola Jadwal</strong>
                </li>      
            </ol>
    </div>
    <div class="col-lg-4">
        <div class="title-action">
            <button data-toggle="modal" href="#tambah-jadwal" class="btn btn-primary float-right" type="submit"><i class="fa fa-pencil-square-o"></i> Tambah Data</button>
        </div>   
    </div>
</div>

<div class="wrapper wrapper-content animated fadeInUp">
    <div class="row">
        <div class="col-lg-12">
            <div class="ibox ">
                <div class="ibox-title">
                    <h5>Daftar Jadwal Audit</h5>
                </div>
                <div class="ibox-content">
                    <div class="table-responsive">
                        <table id="manajemen_jadwal" class="table table-striped table-bordered table-hover manajemen_user" >
                            <thead>
                                <tr>   
                                    <th>Mulai Audit</th>
                                    <th>Selesai Audit</th>
                                    <th>Role User</th>
                                    <th>Jenis Audit</th>
                                    <th>Status</th>
                                    <th>Semester</th>
                                    <!-- <th>Tahun</th> -->
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                    
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th>Mulai Audit</th>
                                    <th>Selesai Audit</th>
                                    <th>Role User</th>
                                    <th>Jenis Audit</th>
                                    <th>Status</th>
                                    <th>Semester</th>
                                    <!-- <th>Tahun</th> -->
                                    <th>Aksi</th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div id="tambah-jadwal" class="modal inmodal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
    <div class="modal-content animated bounceInRight">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
            <!-- <i class="fa fa-user modal-icon"></i> -->
            <h4 class="modal-title">Tambah Data</h4>
        </div>
        <div class="modal-body">
        <form  id="tambah_jadwal" class="form-horizontal">
            <div class="form-group">
                <label class="font-normal"><b>Tanggal Mulai Audit</b><small class="text-info"> (*yyyy-mm-dd")</small></label>
                    <div class="input-group date">
                        <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                        <input id="mulai_audit" name="mulai_audit" type="text" class="form-control" data-provide="datepicker" data-date-format="yyyy-mm-dd" value="2019-09-20">
                    </div>
            </div>
            <div class="form-group">
                <label class="font-normal"><b>Tanggal Selesai Audit</b><small class="text-info"> (*yyyy-mm-dd")</small></label>
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                        <input id="selesai_audit" name="selesai_audit" type="text" class="form-control" data-provide="datepicker" data-date-format="yyyy-mm-dd" value="2019-09-20">
                    </div>
            </div>
            <div class="form-group">
                <label class="font-normal"><b>Role User</b></label>
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                        <select id="role_id" name="role_id" class="form-control m-b">
                            <option value="">-Pilih Role-</option>
                            <?php foreach($role as $row):?>
                                <?php if($row['id_role'] !="1" && $row['id_role'] !="4" ) {?>
                                    <option  value="<?php echo $row['id_role'];?>"><?php echo $row['role'];?></option>
                                 <?php }?>
                            <?php endforeach;?>
                        </select>
                    </div>
            </div>
            <div class="form-group">
                <label class="font-normal"><b>Semester</b></label>
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                        <select id="semester_id" name="semester_id" class="form-control m-b">
                            <option value="">-Pilih Semester-</option>
                            <?php foreach($semester->result() as $row):?>
                                <option  value="<?php echo $row->id_semester;?>"><?php echo $row->semester;?></option>
                            <?php endforeach;?>
                        </select>
                    </div>
            </div>
            <div class="form-group">
                <label class="font-normal"><b>Tahun Ajaran</b></label>
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                        <select id="tahun_akademik_id" name="tahun_akademik_id" class="form-control m-b">
                            <option value="">-Tahun Ajaran-</option>
                            <?php foreach($tahun_akademik->result() as $row):?>
                                <option  value="<?php echo $row->id_tahun_akademik;?>"><?php echo $row->tahun_akademik;?></option>
                            <?php endforeach;?>
                        </select>
                    </div>
            </div>
            <div class="form-group">
                <label class="font-normal"><b>Jenis Audit</b></label>
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-share-alt"></i></span>
                        <select id="jenis_audit_id" name="jenis_audit_id" class="form-control m-b">
                            <option value="">-Pilih Jenis Audit-</option>
                            <?php foreach($jenis_audit->result() as $row):?>
                                <option  value="<?php echo $row->id_jenis_audit;?>"><?php echo $row->jenis_audit;?></option>
                            <?php endforeach;?>
                        </select>
                    </div>
            </div>
        </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Batal</button>
                <button type="submit" id="submit" class="btn btn-primary">Simpan</button>
            </div>
        </form>
    </div>
    </div>
</div>

<div id="ubah_jadwal" class="modal inmodal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content animated bounceInRight">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                    <!-- <i class="fa fa-user modal-icon"></i> -->
                <h4 class="modal-title">Edit Data</h4>
            </div>
        <div class="modal-body">
        <div id="form_edit_jadwal">
        
        </div>
    </div>
</div>
    </div>
</div>


