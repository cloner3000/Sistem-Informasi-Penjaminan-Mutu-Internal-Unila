<div class="row wrapper border-bottom white-bg page-heading">
    <div class="col-lg-8">
        <h2>Audit Mata Kuliah</h2>
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="#">Beranda</a>
                </li>
                <li class="breadcrumb-item active">
                    <strong>Audit Mata Kuliah</strong>
                </li>      
            </ol>
    </div>
</div>
<div class="wrapper wrapper-content animated fadeIn">
    <div class="row">
        <div class="col-lg-12">
            <?php $start_date = strtotime($jadwal->mulai_audit);?>
            <?php  $end_date = strtotime($jadwal->selesai_audit);?>
            <?php $todays_date = strtotime(date("Y-m-d"));?>
                <?php if ($todays_date >= $start_date && $todays_date  <= $end_date ) { ?> 
                    <div class="alert alert-success alert-dismissable">
                        <li> Tanggal <?php echo $jadwal->jenis_audit?>: <strong><?php echo date("d F Y", strtotime($jadwal->mulai_audit)) ?></strong> s.d. <strong><?php echo date("d F Y", strtotime($jadwal->selesai_audit)) ?></strong> untuk para <?php echo $jadwal->role ?> sedang berlangsung</li>
                    </div>
                <?php } else { ?> 
                    <?php if($todays_date < $start_date ) { ?>
                        <div class="alert alert-warning alert-dismissable">
                            <li> Tanggal Audit Matakuliah: <strong><?php echo date("d F Y", strtotime($jadwal->mulai_audit)) ?></strong> s.d. <strong><?php echo date("d F Y", strtotime($jadwal->selesai_audit)) ?></strong> untuk para <?php echo $jadwal->role ?></li>
                        </div>
                    <?php } else {?>
                        <div class="alert alert-danger alert-dismissable">
                            <li> Tanggal Audit Matakuliah: <strong><?php echo date("d F Y", strtotime($jadwal->mulai_audit)) ?></strong> s.d. <strong><?php echo date("d F Y", strtotime($jadwal->selesai_audit)) ?></strong> untuk para <?php echo $jadwal->role ?> sudah berakhir</li>
                        </div>
                    <?php } ?>
                <?php } ?>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <div class="ibox"> 
                <div class="ibox-title">
                    <h5>Form Audit Mata Kuliah</h5>
                    <div class="ibox-tools">
                        <a class="collapse-link">
                            <i class="fa fa-chevron-up"></i>
                        </a>
                        <a class="close-link">
                            <i class="fa fa-times"></i>
                        </a>
                    </div>
                </div>
                <div class="ibox-content">
                    <form>
                        <div class="form-group row">
                            <label class="col-lg-2 col-form-label"><strong>Program Studi *</strong></label>
                            <div class="col-lg-10">
                                <input type="text" disabled value="<?php echo $tpm_prodi['program_studi']?>" placeholder="Program Studi" class="form-control">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-2 col-form-label"><strong>Fakultas *</strong></label>
                            <div class="col-lg-10">
                                <input type="text" disabled value="<?php echo $tpm_prodi['nama_fakultas']?>" placeholder="Fakultas" class="form-control">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-2 col-form-label"><strong>Matakuliah *</strong></label>
                            <div class="col-lg-10">
                                <select id="semester_id" name="semester_id" data-placeholder="Pilih Matakuiliah..." class="matkul form-control m-b" >
                                    <?php foreach($matakuliah as $row):?>
                                        <?php if ($tpm_prodi['prodi_id'] == $row['prodi_id'] ){?>
                                            <option  value="<?php echo $row['id_mata_kuliah'];?>"><?php echo $row['kode_mk'];?> - <?php echo $row['nama_mk'];?> (<?php echo $row['sks_teori'];?> - <?php echo $row['sks_prak'];?>)</option>
                                        <?php } ?>
                                    <?php endforeach;?>
                                </select>
                            </div>
                        </div>
                        <hr>
                        <p>
                            <strong>Dosen Penanggunag Jawab</strong>
                            <button  type="button" type="button" class="add-more btn btn-xs btn-outline btn-rounded btn-primary"><i class="fa fa-plus"></i></button> 
                            <br>
                            <small class="text-success"> *) tekan tombil (+) untuk menambah dosen pj</small>
                        </p>
                        <div class="form-group add-field">
                            <div class="partners">
                                <div class="partner">
                                    <select id="semester_id" name="semester_id" data-placeholder="Pilih Matakuiliah..." class="matkul form-control m-b" >
                                        <?php foreach($dosen as $row):?>
                                            <option  value="<?php echo $row['id'];?>"><?php echo $row['nama'];?> </option>
                                        <?php endforeach;?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                        <?php $start_date = strtotime($jadwal->mulai_audit);?>
                        <?php  $end_date = strtotime($jadwal->selesai_audit);?>
                        <?php $todays_date = strtotime(date("Y-m-d"));?>
                            <?php if ($todays_date >= $start_date && $todays_date  <= $end_date ) { ?> 
                                <button type="submit" id="submit" class="btn btn-primary">Simpan</button>
                            <?php } else { ?> 
                                <?php if($todays_date < $start_date ) { ?>
                                    <button type="submit" disabled id="submit" class="btn btn-primary">Simpan</button>
                                <?php } else {?>
                                    <button type="submit" disabled id="submit" class="btn btn-primary">Simpan</button>
                                <?php } ?>
                            <?php } ?>
                        </div>
                    </form>
                </div>
            </div>      
        </div>
    </div>
</div>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script>
$(document).ready(function(){
var data_fo = $('.partner').html();
var sd = '<div class="btn btn-danger remove-add-more">Remove</div>';
var max_fields = 5; //maximum input boxes allowed
var wrapper = $(".partners"); //Fields wrapper
var add_button = $(".add-more"); //Add button ID

var x = 1; //initlal text box count
$(add_button).click(function(e){ //on add input button click
  e.preventDefault();
  if(x < max_fields){ //max input box allowed
    x++; //text box increment
    var partnerClone = $('.partner').first().clone();
    $(sd).appendTo(partnerClone);
    $(wrapper).append(partnerClone);
  }
});

    $(wrapper).on("click",".remove-add-more", function(e){ //user click on remove text
        e.preventDefault();
        $(this).parent('.partner').remove();
        $(this).remove();
        x--;
    });
});
</script>

