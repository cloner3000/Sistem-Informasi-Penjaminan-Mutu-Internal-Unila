<div class="row wrapper border-bottom white-bg page-heading">
    <div class="col-lg-8">
        <h2>User</h2>
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="index.html">Beranda</a>
                </li>
                <li class="breadcrumb-item active">
                    <strong>Manajemen User</strong>
                </li>      
            </ol>
    </div>
    <div class="col-lg-4">
        <div class="ibox-content center">
            <div class="title-action">
                <button data-toggle="modal" href="#tambah-user" class="btn btn-primary float-right" type="submit"><i class="fa fa-pencil-square-o"></i> Tambah Data</button>
            </div>  
        </div>   
    </div>
</div>

<div class="wrapper wrapper-content animated fadeInRight">
    <div class="row">
        <div class="col-lg-12">
            <div class="ibox ">
                <div class="ibox-title">
                    <h5>Manajemen User</h5>
                </div>
                <div class="ibox-content">
                    <div class="table-responsive">
                        <table id="manajemen_user" class="table table-striped table-bordered table-hover manajemen_user" >
                            <thead>
                                <tr>
                                    <th>Username</th>
                                    <th>Role</th>
                                    <th>Password</th>
                                    <th>Masuk</th>
                                    <th>Status</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                    
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th>Username</th>
                                    <th>Role</th>
                                    <th>Password</th>
                                    <th>Masuk</th>
                                    <th>Status</th>
                                    <th>Aksi</th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div id="tambah-user" class="modal inmodal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
    <div class="modal-content animated bounceInRight">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
            <!-- <i class="fa fa-user modal-icon"></i> -->
            <h4 class="modal-title">Tambah Data</h4>
        </div>
        <div class="modal-body">
        <form  id="tambah_user"class="form-horizontal">
            <div class="form-group">
                <label><b>Role</b></label> 
                <select id="role" name="role_id" class="form-control m-b">
                    <option value="">-Pilih Role-</option>
                  <?php foreach($role->result() as $row):?>
                    <?php if($row->id_role !="1") {?>
                        <option  value="<?php echo $row->id_role;?>"><?php echo $row->role;?></option>
                    <?php }?>
                  <?php endforeach;?>
                </select>
            </div>
            <div id="select_fakultas" class="form-group">
                <label><b>Pusat Lembaga</b></label> 
                <select id="pusat_lembaga_id" name="pusat_lembaga_id" class="form-control m-b">
                    <option value="">-Pilih Pusat Lembaga-</option>
                  <?php foreach($lembaga as $row):?>
                        <option  value="<?php echo $row['id_pusat_lembaga']?>"><?php echo $row['pusat_lembaga'];?></option>
                  <?php endforeach;?>
                </select>
            </div>
            <div id="select_jurusan" class="form-group">
                <label><b>Program Studi</b></label> 
                <select id="prodi_id" name="prodi_id" data-placeholder="Pilih Program Studi..." class="prodi-select">
                  <?php foreach($prodi->result() as $row):?>
                        <option  value="<?php echo $row->id_prodi;?>"><?php echo $row->program_studi;?></option>
                  <?php endforeach;?>
                </select>
            </div>
            <div id="select_lab" class="form-group">
                <label><b>Laboratorium</b></label> 
                <select id="lab_id" name="lab_id"  data-placeholder="Pilih Laboiratorium..."  class="lab-select">
                    <option value="">-Pilih Lab-</option>
                  <?php foreach($lab->result() as $row):?>
                        <option  value="<?php echo $row->id_lab;?>"><?php echo $row->nama_lab;?></option>
                  <?php endforeach;?>
                </select>
            </div>
            <div id="select_unit" class="form-group">
                <label><b>Unit Pelaksana</b></label> 
                <select id="unit_id" name="unit_id" class="form-control m-b">
                    <option value="">-Pilih Unit-</option>
                  <?php foreach($upt as $row):?>
                        <option  value="<?php echo $row['id_upt'];?>"><?php echo $row['unit_pelaksana'];?></option>
                  <?php endforeach;?>
                </select>
            </div>
            <div id="select_badan" class="form-group">
                <label><b>Badan Pengelola</b></label> 
                <select id="badan_id" name="badan_id" class="form-control m-b">
                    <option value="">-Pilih Badan Pengelola-</option>
                  <?php foreach($badan as $row):?>
                        <option  value="<?php echo $row['id_badan'];?>"><?php echo $row['nama_badan'];?></option>
                  <?php endforeach;?>
                </select>
            </div>
            <div class="form-group">
                <label><b>Username</b></label> 
                <input id="username" name="username" type="text" placeholder="username" class="form-control">
            </div>

            <div class="form-group">
                <label><b>Password</b></label> 
                <input id="password" type="text"  name="password" value="unilajaya" placeholder="password" class="form-control">
            </div>

            

        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-danger" data-dismiss="modal">Batal</button>
            <button type="submit" id="submit" class="btn btn-primary">Simpan</button>
        </div>
        </form>
    </div>
    </div>
</div>

<div id="edit_user" class="modal inmodal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
    <div class="modal-content animated bounceInRight">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
            <!-- <i class="fa fa-user modal-icon"></i> -->
            <h4 class="modal-title">Edit Data</h4>
        </div>
        <div class="modal-body">
            <div id="form_edit_user">

            </div>
        </div>
        
    </div>
    </div>
</div>





        