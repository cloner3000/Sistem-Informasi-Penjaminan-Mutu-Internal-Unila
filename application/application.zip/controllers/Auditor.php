<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auditor extends MY_Controller {

    function __construct()
    {
        parent::__construct();
        $this->load->database();
        $this->load->model('Auditor_model');
        $this->load->model('Auth_model');
        $this->load->model('Core_model');
        $this->load->helper('form');
        $this->load->helper('url');

        $this->check_login();
        if ($this->session->userdata('role_id') != "3") {
            redirect('', 'refresh');
        }

        $this->ip_address = $_SERVER['REMOTE_ADDR'];
        $this->time = date('Y-m-d H:i:s');
    }


    public function detail_user()
    {
        $id = $this->uri->segment(3);
        $data= $this->Auditor_model->update_auditor($id);
        if($this->session->userdata('id_user') != $data['user_id']){
            redirect('404');
        }
        $data['detail_user'] = $this->Auditor_model->update_auditor($id);
        $this->template->load('layouts/template', 'content/auditor/detail_auditor', $data);
    }

    public function update_auditor()
    {
        $edit_data = array(
            'id_auditor' =>  $this->input->post('id_auditor'),
            'nama_auditor' => $this->input->post('nama_auditor'),
            'nip_auditor ' => $this->input->post('nip_auditor'),

          );
        
        //print_r($edit_data);
        $id = $this->input->post('id_auditor');
        $data = $this->Auditor_model->act_update_auditor($edit_data, $id);
        redirect('home');
        # code...
    }

    public function update_user()
    {
      $edit_user = array(
        'username' => $this->input->post('username'),
        'password' => get_hash($this->input->post('password')),
        'session' => base64_encode($this->input->post('password')),
      );
  
      $id = $this->input->post('id_user');

      $data = $this->Auditor_model->update_user($edit_user, $id);
      redirect('home');

    }

}