<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Audit_ps extends MY_Controller {

    var $data = array();

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
        $this->load->model('Tpm_model');
        $this->load->model('Dosen_model');
        $this->load->model('Jadwal_model');
        $this->load->model('Core_model');
        $this->load->helper('url');

        $this->check_login();
    
        $this->ip_address = $_SERVER['REMOTE_ADDR'];
        $this->time = date('Y-m-d H:i:s');
    }

    public function audit_matkul()
    {
        $x['semester']=$this->Core_model->get_semester();
        $x['tahun_akademik']=$this->Core_model->get_tahun_akademik();

        $id = $this->session->userdata('role_id');
        $user_id = $this->session->userdata('id_user');
        $x['tpm_prodi'] = $this->Tpm_model->get_tpm_prodi_id($user_id);
        $x['jadwal'] = $this->Jadwal_model->get_jadwal_matkul($id);
        $x['jenis_audit']=$this->Core_model->get_jenis_audit();
        $x['matakuliah'] = $this->Core_model->get_detail_matakuliah();
        $x['dosen'] = $this->Dosen_model->get_dosen();
        $this->template->load('layouts/template', 'content/audit/ps/audit_matakuliah', $x);
    }
}